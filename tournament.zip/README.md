# CS400_Bracket
Group project from CS400 offered by UW-Madison in spring 2018
Bracket.java, GraphGenerator.java, Main.java and style.css are originally created by HarveyWangWisc.
Alertbox.java is originally created by Tiejean.
